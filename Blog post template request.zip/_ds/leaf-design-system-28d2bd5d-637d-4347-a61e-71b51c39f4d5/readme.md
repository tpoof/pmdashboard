# LEAF Design System

A design system for **LEAF — Light Electronic Action Framework**, the U.S. Department of Veterans Affairs' open-source platform that lets non-technical staff digitize paper processes into online forms and routed approval workflows. *"Built by VA for VA,"* LEAF empowers users to implement workflows and digitize business processes with minimal startup cost, standardizing best practices through a shared Form Library.

This project is the **single source of truth** for building LEAF-branded interfaces — production UI or throwaway mocks. It packages the brand assets, the design tokens (which mirror the U.S. Web Design System / USWDS that LEAF is built on), reusable React components, and full-screen UI-kit recreations of the product.

---

## Sources

Everything here was reverse-engineered from the materials below. The reader is **not** assumed to have access; these are recorded for provenance and future updates.

| Source | Location | What we took from it |
|---|---|---|
| **LEAF codebase** | mounted folder `leaf-repo/LEAF/` (the VA's open-source LEAF repo) | All tokens, component styling, layout patterns, icons and fonts |
| `…/app/libs/css/leaf.css` | shared lib | Font Awesome 6.7.2 build + `@font-face` rules |
| `…/app/libs/css/fonts/` | shared lib | Public Sans, Source Sans Pro, Font Awesome webfont binaries (copied into `assets/fonts/`) |
| `…/app/libs/dynicons/svg/` | shared lib | "Dynicons" — Tango/GNOME-style SVG icons for forms, folders & menu tiles |
| `…/LEAF_Request_Portal/css/style.css` | request portal | Legacy portal layout, button & grid patterns, brand hexes |
| `…/LEAF_Request_Portal/js/` + `…/app/libs/js/vue-dest/` | Vue 3 admin | Form-editor / form-browser UI structure |
| **Uploaded brand assets** | `uploads/` | `LEAF-logo.svg/.png`, `LEAF_logo_transparent.png`, `leaf-profile-icon.png` (copied into `assets/`) |

> **Underlying framework:** LEAF follows the **U.S. Web Design System (USWDS)**. Where this guide says "USWDS primary" etc., the hexes are the exact values pulled from the production stylesheets, not invented.

---

## Brand at a glance

- **Name:** LEAF — Light Electronic Action Framework (VA Office of Workflow Solutions).
- **Logo:** a green leaf mark beside the wordmark "LE🍃F" where the **A** is rendered in blue. The leaf alone is the app icon / profile mark.
- **Brand colors:** leaf green `#7BC143`, accent blue `#0071BD`. These are *brand/marketing* colors — the **product UI runs on the USWDS palette** (action blue `#005EA2`, navy chrome `#252F3E`, cool grays).
- **Type:** Public Sans (headings, UI chrome) + Source Sans Pro (body, form labels). Both are USWDS system typefaces.
- **Voice:** plain, direct, government-service tone. Accessibility (Section 508) is a first-class constraint, not an afterthought.

---

## CONTENT FUNDAMENTALS

How LEAF writes copy. LEAF is a federal government tool, so the voice is **plain-language, task-focused, and Section 508 / plain-writing-act compliant.**

- **Tone:** calm, procedural, and reassuring. Never playful, never marketing-hyped. The product helps people complete official requests, so copy reads like a competent colleague walking you through a form.
- **Person:** addresses the user as **"you"**; the system refers to itself implicitly ("Your request has been submitted") rather than as "we". Admin/help docs use imperative voice ("Select a form to begin").
- **Casing:** **Sentence case** everywhere — headings, buttons, menu items, table headers. Title Case appears only in proper nouns and the org name (e.g. "Veterans Health Administration"). Buttons read "Save", "Cancel", "Submit request", "Add user".
- **Labels:** form fields use short noun labels ("Requestor name", "Justification", "Service"). Required fields take a red asterisk. Help/hint text is a complete, plain sentence under the label.
- **Status language:** workflow states are single, capitalized words or short phrases — *Pending, Approved, Returned, In progress, Draft, Cancelled.* Confirmations are factual and specific ("Request #VHA-20482 routed to your supervisor").
- **Errors:** describe the problem and the fix, plainly: "Enter a valid email address." No blame, no jokes, no "Oops!".
- **Numbers & IDs:** request/record IDs are prominent and monospace-friendly; dates are spelled or `MM/DD/YYYY`. Counts are surfaced bluntly ("3 items awaiting review").
- **Emoji:** **none.** This is a federal system. Iconography carries all visual signaling.
- **Acronyms:** heavy VA domain usage (VHA, VBA, OIT). Expand on first use where space allows; the audience is internal staff who know them.
- **Vibe:** *trustworthy, efficient, unfussy.* The writing gets out of the way so the task can get done.

**Examples (representative):**
- Tagline: "Built by VA for VA — empower non-technical users to digitize and route any business process."
- Button set: `Save` · `Cancel` · `Submit request` · `Add a question` · `Apply`
- Empty state: "You have no requests awaiting your review."
- Confirmation: "Your request has been submitted. Tracking #VHA-20482."

---

## VISUAL FOUNDATIONS

The look is **clean, dense, accessible USWDS** — a government productivity tool, not a consumer app. Function over flourish.

- **Color vibe:** cool and institutional. A neutral cool-gray page (`#DCDEE0`), white content surfaces, a dark navy header bar (`#252F3E`), and a single confident **action blue** (`#005EA2`) carrying nearly all interactivity. The leaf-green brand color is reserved for the logo and the occasional success/accent moment — it is **not** a UI workhorse.
- **Backgrounds:** flat fills only. **No gradients, no photographic hero imagery, no textures or patterns** in the product. The page is gray, cards are white. (Marketing/landing contexts may use the green leaf mark as a motif, but the app itself stays flat.)
- **Type:** Public Sans Bold for headings and UI chrome; Source Sans Pro for body and form labels; field "responses" render in a monospace face. Sizes are rem-based on a 16px root; controls (buttons, inputs, labels) sit at ~17px for touch/readability.
- **Spacing:** rem-based rhythm (4 / 8 / 12 / 16 / 24 / 32 / 48 / 64px). Comfortable but efficient — this is a forms tool, so density matters.
- **Corner radii:** **small.** Inputs 2px, buttons/nav 3px, cards/dialogs 4px, sitemap tiles 5px. Pills (999px) only for badges. Nothing is heavily rounded.
- **Borders:** hairline (`1px`) dividers in light gray for tables, lists and card footers. Interactive controls use a **2px** border; alerts and "current" markers use a **4px** colored left-bar.
- **Shadows:** soft, low-opacity, in a **cool near-black** (`rgba(0,0,20…25, .2–.4)`) — never warm, never heavy. Cards get a 1–3px shadow; dialogs get a diffuse `0 0 5px` glow; dragged items get an offset ghost shadow. No neumorphism, no glow.
- **Elevation logic:** flat by default; shadow signals "this floats" (menus, dialogs, drag states, the sticky header).
- **Hover states:** links and nav items darken to a deeper blue and pick up a light gray wash; primary buttons keep their fill but gain a **2px black border**; cards lift their shadow. Subtle, never bouncy.
- **Press/active states:** same black-border treatment as hover; no scale/shrink animation.
- **Focus:** a visible **3px `#2491FF` outline** on every interactive element — non-negotiable for 508 compliance. Never removed, only restyled.
- **Transparency & blur:** essentially **none.** Surfaces are opaque. No glassmorphism, no backdrop blur.
- **Animation:** minimal and functional. Color/filter transitions ~0.25s, shadow/box transitions ~0.4s, all plain `ease`. No bounces, no spring, no decorative looping motion. A spinner GIF covers async loads. Respect `prefers-reduced-motion`.
- **Cards:** white fill, small radius (4–5px), soft cool shadow, optional 1px border on the "bordered" variant; a hairline-divided footer for actions. Titles in Public Sans Medium, navy.
- **Layout:** centered content columns (grid container ≈1024px; admin ≈1088px; the form-editor canvas runs much wider). A fixed/sticky dark header with the logo; USWDS side navigation with a left-bar current marker; data-dense grids and tables.
- **Imagery:** the product is essentially image-free apart from the logo and icons. When imagery appears, keep it literal and utilitarian.

---

## ICONOGRAPHY

LEAF uses **two** icon systems, both copied into `assets/` — never hand-draw or generate icons; pull from these.

1. **Font Awesome 6 Free (Solid)** — the modern UI icon font, loaded across the Vue app. This is the primary set for chrome, actions and status. Use via the font: `<i class="fa-solid fa-house" aria-hidden="true"></i>`. The webfont binary lives at `assets/fonts/fontawesome/` and the base classes + a curated glyph subset are in `tokens/icons.css`. Add more glyphs by adding a `.fa-<name>::before { content: "\f###"; }` rule with the official FA6 codepoint. Icons inherit `currentColor`, so they take on the action-blue / status colors of their context.
2. **Dynicons** — a set of **Tango/GNOME-style SVG icons** (`assets/icons/`) the original app uses for forms, folders, menu tiles and dialogs (`document-new.svg`, `folder-open.svg`, `dialog-warning.svg`, `printer.svg`, etc.). These are full-color raster-feel SVGs; use them at 24–34px for menu/sitemap tiles and form-type indicators, where Font Awesome's monochrome glyphs would feel too plain.

**Rules:**
- **No emoji.** Federal system; emoji never appear in product UI.
- **No raw Unicode pictographs** as icons — use Font Awesome or a dynicon.
- Font Awesome for monochrome inline UI icons (buttons, nav, table actions, alerts). Dynicons for the colorful tile/menu/form-type imagery.
- Always pair icons with text labels or `aria-label`s — accessibility is required.

See the **Brand** cards in the Design System tab for live specimens of both sets.

---

## How it's organized

```
styles.css              ← the ONE file consumers link; @import manifest only
tokens/
  fonts.css             ← @font-face: Public Sans, Source Sans Pro, Font Awesome
  colors.css            ← brand + USWDS palette, semantic aliases
  typography.css        ← families, size scale, weights, line-heights
  spacing.css           ← spacing, radii, borders, shadows, layout, motion, z-index
  icons.css             ← Font Awesome base classes + curated glyph set
  base.css              ← element defaults (body, headings, links, focus ring)
guidelines/             ← foundation specimen cards (Design System tab)
components/             ← reusable React primitives (see list below)
  actions/  forms/  feedback/  surfaces/  data/
ui_kits/                ← full-screen product recreations
assets/
  fonts/  logos/  icons/ (dynicons)  brand/
readme.md               ← this file
SKILL.md                ← Agent-Skills entry point for download/Claude Code
```

### Tokens
Reference the **semantic aliases** in product code (`--action-primary`, `--surface-card`, `--text-muted`, `--border-subtle`) rather than the raw scale (`--color-primary`, `--color-base-dark`). Every token is declared on `:root` in a file reachable from `styles.css`, so the compiler ships and indexes them all.

### Components (`window.LEAFDesignSystem_28d2bd.*`)
| Component | Group | Purpose |
|---|---|---|
| `Button` | actions | Primary action control (USWDS `.usa-button`) — 5 variants, 3 sizes |
| `IconButton` | actions | Square icon-only button for toolbars & table rows |
| `TextField` | forms | Labelled input / textarea with hint + error states |
| `Checkbox` | forms | LEAF "leaf_check" checkbox / radio |
| `Alert` | feedback | Inline status banner (info / success / warning / error) |
| `Badge` | feedback | Workflow-state pill / count |
| `Card` | surfaces | White content panel with soft cool elevation |
| `SideNav` | surfaces | USWDS vertical nav with left-bar current marker |
| `Table` | data | Presentational data grid for inboxes & reports |
| `AdvancedSearch` | data | Search box with an expandable AND/OR advanced-filter builder |

Each component directory holds `<Name>.jsx` (implementation), `<Name>.d.ts` (props contract + starting-point tag), `<Name>.prompt.md` (one-line "what & when" + usage), and a `*.card.html` thumbnail for the Design System tab. Components style themselves purely through the CSS custom properties, so they always track the tokens.

### UI kits
Full-screen, click-through recreations of real LEAF product views, composed from the components above.

- **`ui_kits/request_portal/`** — the **LEAF Request Portal**, the primary user-facing product. Seven linked screens: Login → Homepage (colorful menu tiles + `leaf_grid` records table) → New Request (type picker → form → confirmation) → Inbox (role-grouped grids with Take Action workflow dialog) → Report Builder (2-step filter + column wizard) → Record view (responses + workflow-progress sidebar + Tools toolbar) → Admin Panel (grouped `leaf-admin-button` tile grid). See its `README.md` for the screen-by-screen source mapping. This is a visual recreation of the **existing** product — not a new design.

Open `ui_kits/request_portal/index.html` to use it.

---

## Using this system

- **Consumers** link one file: `styles.css`. That pulls in every token and webfont.
- In a mock or prototype, copy the assets you reference out of `assets/` (you can't hot-link across projects) and write static HTML.
- For production work, read the component `.prompt.md` files and the guideline cards, then build with the tokens.
- **Do not** edit `_ds_bundle.js`, `_ds_manifest.json`, or `_adherence.oxlintrc.json` — the compiler regenerates them.

---

## Font substitution note
All four typefaces (Public Sans, Source Sans Pro, Font Awesome 6 Free) were copied from the LEAF codebase as the original webfont binaries — **no substitutions were required.**
