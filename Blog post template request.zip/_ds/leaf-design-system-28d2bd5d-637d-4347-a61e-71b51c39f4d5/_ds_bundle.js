/* @ds-bundle: {"format":3,"namespace":"LEAFDesignSystem_28d2bd","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"AdvancedSearch","sourcePath":"components/data/AdvancedSearch.jsx"},{"name":"Table","sourcePath":"components/data/Table.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Badge","sourcePath":"components/feedback/Badge.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"SideNav","sourcePath":"components/surfaces/SideNav.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"c43e1202b5de","components/actions/IconButton.jsx":"f21923b36692","components/data/AdvancedSearch.jsx":"8cc9d8f368a8","components/data/Table.jsx":"79797000b301","components/feedback/Alert.jsx":"4a9e28cea27e","components/feedback/Badge.jsx":"ce4a4d887712","components/forms/Checkbox.jsx":"5c159b2e4998","components/forms/TextField.jsx":"349d25c6cac1","components/surfaces/Card.jsx":"db8afb45eaca","components/surfaces/SideNav.jsx":"a81671c02803","ui_kits/request_portal/AdminScreen.jsx":"1af43ba51278","ui_kits/request_portal/HomeScreen.jsx":"5bf4651af4d0","ui_kits/request_portal/InboxScreen.jsx":"edb284c0d180","ui_kits/request_portal/LoginScreen.jsx":"64d7b8167ff6","ui_kits/request_portal/NewRequestScreen.jsx":"406d77bdc380","ui_kits/request_portal/PortalChrome.jsx":"448cdb67a757","ui_kits/request_portal/RecordScreen.jsx":"f0d5a53eace8","ui_kits/request_portal/ReportBuilderScreen.jsx":"ab2222bab139","ui_kits/request_portal/data.js":"cac8ab819831"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.LEAFDesignSystem_28d2bd = window.LEAFDesignSystem_28d2bd || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Inject component CSS once. Uses LEAF design tokens (var(--…)) so it
   always tracks styles.css. Mirrors USWDS .usa-button from leaf.css. */
const CSS = `
.lds-btn{
  cursor:pointer; display:inline-flex; align-items:center; justify-content:center;
  gap:.5rem; min-width:6rem; padding:.75rem 1rem; line-height:.9;
  font-family:var(--font-display-bold); font-size:var(--text-lg); font-weight:700;
  white-space:nowrap; text-decoration:none; text-align:center;
  color:#fff; background-color:var(--action-primary);
  border:var(--border-control) solid transparent; border-radius:var(--radius-md);
  background-clip:padding-box; transition:background-color var(--duration-fast) var(--ease-standard);
}
.lds-btn:hover,.lds-btn:focus,.lds-btn:active{ border:var(--border-control) solid #000; outline:none; }
.lds-btn:focus-visible{ outline:var(--focus-ring); outline-offset:2px; }
.lds-btn--secondary{ background-color:var(--action-secondary); }
.lds-btn--success{ background-color:var(--action-success); }
.lds-btn--base{ background-color:var(--action-muted); }
.lds-btn--outline{
  color:var(--action-primary); background-color:transparent;
  box-shadow:inset 0 0 0 var(--border-control) var(--action-primary);
}
.lds-btn--outline:hover,.lds-btn--outline:focus{ background-color:var(--color-primary-surface); }
.lds-btn--sm{ padding:.5rem .75rem; font-size:var(--text-sm); min-width:0; }
.lds-btn--lg{ padding:1rem 1.5rem; font-size:var(--text-xl); }
.lds-btn[disabled],.lds-btn.is-disabled{
  cursor:not-allowed; color:var(--color-disabled-fg);
  background-color:var(--color-disabled-bg); box-shadow:none; border-color:transparent;
}
.lds-btn--block{ width:100%; }
`;
function useInjectedCss(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id;
    el.textContent = css;
    document.head.appendChild(el);
  }, [id, css]);
}

/**
 * Button — the primary LEAF action control (USWDS .usa-button).
 */
function Button({
  variant = "primary",
  size = "md",
  block = false,
  disabled = false,
  iconBefore = null,
  iconAfter = null,
  children,
  className = "",
  ...rest
}) {
  useInjectedCss("lds-btn-css", CSS);
  const classes = ["lds-btn", variant !== "primary" ? `lds-btn--${variant}` : "", size !== "md" ? `lds-btn--${size}` : "", block ? "lds-btn--block" : "", disabled ? "is-disabled" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("button", _extends({
    className: classes,
    disabled: disabled
  }, rest), iconBefore ? /*#__PURE__*/React.createElement("i", {
    className: `fa-solid fa-${iconBefore}`,
    "aria-hidden": "true"
  }) : null, children, iconAfter ? /*#__PURE__*/React.createElement("i", {
    className: `fa-solid fa-${iconAfter}`,
    "aria-hidden": "true"
  }) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.lds-iconbtn{
  cursor:pointer; display:inline-flex; align-items:center; justify-content:center;
  width:2.25rem; height:2.25rem; padding:0; color:var(--action-primary);
  background-color:var(--color-primary-surface);
  border:var(--border-control) solid var(--action-primary); border-radius:var(--radius-sm);
  transition:background-color var(--duration-fast) var(--ease-standard);
}
.lds-iconbtn:hover,.lds-iconbtn:focus,.lds-iconbtn:active{
  background-color:var(--action-primary); color:#fff; border-color:#000; outline:none;
}
.lds-iconbtn:focus-visible{ outline:var(--focus-ring); outline-offset:2px; }
.lds-iconbtn--ghost{ background-color:transparent; border-color:transparent; }
.lds-iconbtn--ghost:hover,.lds-iconbtn--ghost:focus{
  background-color:var(--color-primary-surface); color:var(--action-primary); border-color:transparent;
}
.lds-iconbtn--danger{ color:#fff; background-color:var(--color-secondary); border-color:var(--color-secondary); }
.lds-iconbtn--danger:hover,.lds-iconbtn--danger:focus{ background-color:#600; border-color:#000; }
.lds-iconbtn--sm{ width:1.75rem; height:1.75rem; font-size:.8rem; }
.lds-iconbtn[disabled]{ cursor:not-allowed; color:var(--color-disabled-fg);
  background-color:var(--color-disabled-bg); border-color:transparent; }
`;
function useInjectedCss(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id;
    el.textContent = css;
    document.head.appendChild(el);
  }, [id, css]);
}

/**
 * IconButton — a compact square action button holding a single Font Awesome icon.
 */
function IconButton({
  icon,
  label,
  variant = "default",
  size = "md",
  disabled = false,
  className = "",
  ...rest
}) {
  useInjectedCss("lds-iconbtn-css", CSS);
  const classes = ["lds-iconbtn", variant !== "default" ? `lds-iconbtn--${variant}` : "", size !== "md" ? `lds-iconbtn--${size}` : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("button", _extends({
    className: classes,
    disabled: disabled,
    "aria-label": label,
    title: label
  }, rest), /*#__PURE__*/React.createElement("i", {
    className: `fa-solid fa-${icon}`,
    "aria-hidden": "true"
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/data/AdvancedSearch.jsx
try { (() => {
/* LEAF advanced search — recreates LeafFormSearch's "Advanced Options" panel:
   a search input + an expandable fieldset of filter rows (remove · AND/OR gate ·
   field · operator · value) with And…/Or… adders and a full-width Apply Filters
   button. Styling follows the legacy portal (buttonNorm, 1px black border). */

const CSS = `
.lds-search{ font-family: var(--font-body); color: var(--text-default); }
.lds-search__bar{ display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
.lds-search__icon{ color: var(--color-base-dark); }
.lds-search__input{
  flex:1; min-width:200px; padding:5px 8px; font-size:var(--text-md); font-family:var(--font-body);
  border:1px solid #000; border-radius:0;
}
.lds-search__btn{
  cursor:pointer; padding:4px 10px; font-family:var(--font-body); font-size:var(--text-sm);
  color:#000; background:#e8f2ff; border:1px solid #000; border-radius:0;
}
.lds-search__btn:hover,.lds-search__btn:focus{ background:#2372b0; color:#fff; outline:none; }
.lds-search__panel{
  margin-top:6px; border:1px solid #000; background:#fff; padding:10px 12px 12px; position:relative;
}
.lds-search__legend{ font-family:var(--font-display-bold); font-size:var(--text-sm); padding:0 4px; }
.lds-search__hint{ font-size:var(--text-sm); color:var(--text-muted); margin:2px 0 8px; }
.lds-search__terms{ width:100%; border-collapse:separate; border-spacing:5px; }
.lds-search__terms td{ vertical-align:middle; }
.lds-search__gate{ font-family:var(--font-display-bold); font-size:var(--text-xs); color:var(--color-base-darker); }
.lds-search__remove{
  cursor:pointer; width:22px; height:22px; display:inline-flex; align-items:center; justify-content:center;
  border:1px solid var(--color-base-light); background:#fff; border-radius:2px; color:var(--color-secondary);
}
.lds-search__remove:hover{ background:var(--color-error-surface); }
.lds-search select, .lds-search__val{
  padding:3px 4px; font-family:var(--font-body); font-size:var(--text-sm);
  border:1px solid var(--color-base-dark); border-radius:2px; background:#fff;
}
.lds-search__val{ width:100%; box-sizing:border-box; }
.lds-search__adders{ display:flex; gap:6px; margin:8px 0; }
.lds-search__warn{ color:#b00; font-size:var(--text-sm); margin:6px 2px; }
.lds-search__apply{
  width:100%; cursor:pointer; padding:6px; font-family:var(--font-body); font-size:var(--text-md);
  color:#000; background:#e8f2ff; border:1px solid #000;
}
.lds-search__apply:hover,.lds-search__apply:focus{ background:#2372b0; color:#fff; outline:none; }
`;
const FIELDS = [{
  value: "stepID",
  label: "Current Status",
  ops: ["IS", "IS NOT"],
  kind: "status"
}, {
  value: "data",
  label: "Data Field",
  ops: ["CONTAINS", "DOES NOT CONTAIN", "=", "!="],
  kind: "text"
}, {
  value: "dateSubmitted",
  label: "Date Submitted",
  ops: ["ON", "ON AND AFTER", "ON AND BEFORE"],
  kind: "date"
}, {
  value: "userID",
  label: "Initiator",
  ops: ["IS", "IS NOT"],
  kind: "text"
}, {
  value: "serviceID",
  label: "Service",
  ops: ["IS", "IS NOT"],
  kind: "service"
}, {
  value: "title",
  label: "Title",
  ops: ["CONTAINS", "DOES NOT CONTAIN", "=", "!="],
  kind: "text"
}, {
  value: "categoryID",
  label: "Type",
  ops: ["IS", "IS NOT"],
  kind: "type"
}, {
  value: "recordID",
  label: "Record ID",
  ops: ["=", "!="],
  kind: "text"
}, {
  value: "dependencyID",
  label: "Requirement",
  ops: ["IS", "IS NOT"],
  kind: "text"
}];
function useInjectedCss(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id;
    el.textContent = css;
    document.head.appendChild(el);
  }, [id, css]);
}
let _uid = 0;

/**
 * AdvancedSearch — search box with an expandable advanced-filter builder.
 */
function AdvancedSearch({
  placeholder = "Search…",
  services = ["Cardiology", "Radiology", "Emergency Dept", "Pharmacy", "Nursing"],
  types = ["General Leave Request", "Equipment Request", "Telework Agreement", "Travel Authorization", "System Access Request"],
  statuses = ["Submitted", "Pending Supervisor", "Pending Service Chief", "Approved", "Returned"],
  onSearch,
  onApply,
  className = ""
}) {
  useInjectedCss("lds-search-css", CSS);
  const [text, setText] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const [rows, setRows] = React.useState(() => [{
    id: ++_uid,
    gate: "AND",
    field: "title",
    op: "CONTAINS",
    value: ""
  }]);
  const addRow = gate => setRows(r => [...r, {
    id: ++_uid,
    gate,
    field: "title",
    op: "CONTAINS",
    value: ""
  }]);
  const removeRow = id => setRows(r => r.length > 1 ? r.filter(x => x.id !== id) : r);
  const update = (id, patch) => setRows(r => r.map(x => {
    if (x.id !== id) return x;
    const next = {
      ...x,
      ...patch
    };
    if (patch.field) {
      const f = FIELDS.find(f => f.value === patch.field);
      next.op = f.ops[0];
      next.value = "";
    }
    return next;
  }));
  const optionsFor = field => {
    const f = FIELDS.find(f => f.value === field);
    if (f.kind === "service") return services;
    if (f.kind === "type") return types;
    if (f.kind === "status") return statuses;
    return null;
  };
  return /*#__PURE__*/React.createElement("div", {
    className: ["lds-search", className].filter(Boolean).join(" ")
  }, /*#__PURE__*/React.createElement("div", {
    className: "lds-search__bar"
  }, /*#__PURE__*/React.createElement("i", {
    className: "fa-solid fa-magnifying-glass lds-search__icon",
    "aria-hidden": "true"
  }), !open && /*#__PURE__*/React.createElement("input", {
    className: "lds-search__input",
    type: "text",
    value: text,
    placeholder: placeholder,
    "aria-label": "Search",
    onChange: e => setText(e.target.value),
    onKeyDown: e => {
      if (e.key === "Enter" && onSearch) onSearch(text);
    }
  }), !open ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "lds-search__btn",
    onClick: () => setOpen(true)
  }, "Advanced Options") : /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "lds-search__btn",
    onClick: () => setOpen(false)
  }, "Close advanced search")), open && /*#__PURE__*/React.createElement("fieldset", {
    className: "lds-search__panel"
  }, /*#__PURE__*/React.createElement("legend", {
    className: "lds-search__legend"
  }, "Advanced Search Options"), /*#__PURE__*/React.createElement("div", {
    className: "lds-search__hint"
  }, "Find items where\u2026"), /*#__PURE__*/React.createElement("table", {
    className: "lds-search__terms"
  }, /*#__PURE__*/React.createElement("tbody", null, rows.map((row, i) => {
    const f = FIELDS.find(f => f.value === row.field);
    const opts = optionsFor(row.field);
    return /*#__PURE__*/React.createElement("tr", {
      key: row.id
    }, /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("button", {
      type: "button",
      className: "lds-search__remove",
      "aria-label": "Remove filter row",
      onClick: () => removeRow(row.id)
    }, /*#__PURE__*/React.createElement("i", {
      className: "fa-solid fa-xmark",
      "aria-hidden": "true"
    }))), /*#__PURE__*/React.createElement("td", {
      style: {
        textAlign: "center"
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "lds-search__gate"
    }, i === 0 ? "" : row.gate)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("select", {
      "aria-label": "Field",
      value: row.field,
      onChange: e => update(row.id, {
        field: e.target.value
      }),
      style: {
        width: 150
      }
    }, FIELDS.map(f => /*#__PURE__*/React.createElement("option", {
      key: f.value,
      value: f.value
    }, f.label)))), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("select", {
      "aria-label": "Condition",
      value: row.op,
      onChange: e => update(row.id, {
        op: e.target.value
      }),
      style: {
        width: 150
      }
    }, f.ops.map(o => /*#__PURE__*/React.createElement("option", {
      key: o,
      value: o
    }, o)))), /*#__PURE__*/React.createElement("td", {
      style: {
        width: "40%"
      }
    }, opts ? /*#__PURE__*/React.createElement("select", {
      className: "lds-search__val",
      "aria-label": "Value",
      value: row.value,
      onChange: e => update(row.id, {
        value: e.target.value
      })
    }, /*#__PURE__*/React.createElement("option", {
      value: ""
    }, "Select\u2026"), opts.map(o => /*#__PURE__*/React.createElement("option", {
      key: o,
      value: o
    }, o))) : /*#__PURE__*/React.createElement("input", {
      className: "lds-search__val",
      type: f.kind === "date" ? "date" : "text",
      "aria-label": "Value",
      value: row.value,
      onChange: e => update(row.id, {
        value: e.target.value
      })
    })));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "lds-search__adders"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "lds-search__btn",
    onClick: () => addRow("AND")
  }, "And\u2026"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "lds-search__btn",
    onClick: () => addRow("OR")
  }, "Or\u2026")), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "lds-search__apply",
    onClick: () => onApply && onApply(rows)
  }, "Apply Filters")));
}
Object.assign(__ds_scope, { AdvancedSearch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/AdvancedSearch.jsx", error: String((e && e.message) || e) }); }

// components/data/Table.jsx
try { (() => {
const CSS = `
.lds-table{
  width:100%; border-collapse:separate; border-spacing:0; font-family:var(--font-body);
  font-size:var(--text-sm); line-height:1.5; color:var(--color-ink); background:#fff;
  border:1px solid var(--color-base-darkest); border-radius:var(--radius-xs); overflow:hidden;
}
.lds-table th,.lds-table td{ text-align:left; padding:.5em 1em; border-bottom:1px solid var(--border-default); }
.lds-table thead th{
  font-family:var(--font-display-bold); font-weight:700; background:var(--color-base-lighter);
  color:var(--color-base-darkest); white-space:nowrap;
}
.lds-table tbody tr:last-child td{ border-bottom:0; }
.lds-table tbody tr:hover{ background:var(--color-primary-surface); }
.lds-table--dark thead th{ background:var(--color-base-darkest); color:#fff; }
.lds-table--striped tbody tr:nth-child(even){ background:var(--color-gray-2); }
.lds-table--striped tbody tr:nth-child(even):hover{ background:var(--color-primary-surface); }
.lds-table__sort{
  background:none; border:0; padding:0; margin-left:.4em; cursor:pointer;
  color:inherit; font-size:.75rem; opacity:.7;
}
`;
function useInjectedCss(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id;
    el.textContent = css;
    document.head.appendChild(el);
  }, [id, css]);
}

/**
 * Table — a presentational data grid (USWDS table / LEAF leaf_grid). Pass
 * `columns` (with optional render fns) and `rows`.
 */
function Table({
  columns = [],
  rows = [],
  variant = "default",
  striped = false,
  className = ""
}) {
  useInjectedCss("lds-table-css", CSS);
  const classes = ["lds-table", variant !== "default" ? `lds-table--${variant}` : "", striped ? "lds-table--striped" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("table", {
    className: classes
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map((c, i) => /*#__PURE__*/React.createElement("th", {
    key: i,
    style: c.width ? {
      width: c.width
    } : undefined
  }, c.header, c.sortable ? /*#__PURE__*/React.createElement("button", {
    className: "lds-table__sort",
    "aria-label": "Sort"
  }, /*#__PURE__*/React.createElement("i", {
    className: "fa-solid fa-sort"
  })) : null)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((row, ri) => /*#__PURE__*/React.createElement("tr", {
    key: ri
  }, columns.map((c, ci) => /*#__PURE__*/React.createElement("td", {
    key: ci
  }, c.render ? c.render(row) : row[c.key]))))));
}
Object.assign(__ds_scope, { Table });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Table.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
const CSS = `
.lds-alert{
  display:flex; align-items:flex-start; gap:.6rem; padding:.75rem 1rem;
  font-family:var(--font-body); font-size:var(--text-md); line-height:1.4; color:var(--text-default);
  background:#fff; border-left:var(--border-accent) solid var(--status-info);
}
.lds-alert__icon{ flex:0 0 auto; font-size:1.1rem; line-height:1.4; color:var(--status-info); }
.lds-alert__body{ flex:1; }
.lds-alert__title{ font-family:var(--font-display-bold); margin:0 0 .15rem 0; }
.lds-alert__body p{ margin:0; }
.lds-alert--info{ border-left-color:var(--status-info); background:var(--color-primary-surface); }
.lds-alert--info .lds-alert__icon{ color:var(--color-primary); }
.lds-alert--success{ border-left-color:var(--color-success-border); background:var(--color-success-surface); }
.lds-alert--success .lds-alert__icon{ color:var(--color-success-dark); }
.lds-alert--warning{ border-left-color:var(--color-warning); background:var(--color-warning-fill); }
.lds-alert--warning .lds-alert__icon{ color:#9a6700; }
.lds-alert--error{ border-left-color:var(--color-error-accent); background:var(--color-error-surface); }
.lds-alert--error .lds-alert__icon{ color:var(--color-error-accent); }
`;
const ICONS = {
  info: "circle-info",
  success: "circle-check",
  warning: "triangle-exclamation",
  error: "circle-exclamation"
};
function useInjectedCss(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id;
    el.textContent = css;
    document.head.appendChild(el);
  }, [id, css]);
}

/**
 * Alert — an inline status message (USWDS alert / LEAF entry_* banner)
 * with a colored left bar and a leading status icon.
 */
function Alert({
  variant = "info",
  title,
  children,
  icon,
  className = ""
}) {
  useInjectedCss("lds-alert-css", CSS);
  const glyph = icon || ICONS[variant] || ICONS.info;
  return /*#__PURE__*/React.createElement("div", {
    className: ["lds-alert", `lds-alert--${variant}`, className].filter(Boolean).join(" "),
    role: variant === "error" ? "alert" : "status"
  }, /*#__PURE__*/React.createElement("i", {
    className: `lds-alert__icon fa-solid fa-${glyph}`,
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    className: "lds-alert__body"
  }, title ? /*#__PURE__*/React.createElement("p", {
    className: "lds-alert__title"
  }, title) : null, typeof children === "string" ? /*#__PURE__*/React.createElement("p", null, children) : children));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Badge.jsx
try { (() => {
const CSS = `
.lds-badge{
  display:inline-flex; align-items:center; gap:.35rem; padding:.15rem .55rem;
  font-family:var(--font-display-medium); font-size:var(--text-xs); line-height:1.4;
  border-radius:var(--radius-pill); white-space:nowrap;
  color:#fff; background:var(--color-base);
}
.lds-badge--neutral{ color:var(--text-default); background:var(--color-base-lighter); }
.lds-badge--info{ color:#04323a; background:var(--color-accent-cool); }
.lds-badge--primary{ color:#fff; background:var(--color-primary); }
.lds-badge--success{ color:#fff; background:var(--color-success); }
.lds-badge--warning{ color:#3d2c00; background:var(--color-gold-10v, #ffe396); }
.lds-badge--error{ color:#fff; background:var(--color-secondary); }
.lds-badge__dot{ width:7px; height:7px; border-radius:50%; background:currentColor; opacity:.9; }
.lds-badge--square{ border-radius:var(--radius-sm); }
`;
function useInjectedCss(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id;
    el.textContent = css;
    document.head.appendChild(el);
  }, [id, css]);
}

/**
 * Badge — a small status pill for request states, counts and tags.
 */
function Badge({
  variant = "neutral",
  dot = false,
  square = false,
  children,
  className = ""
}) {
  useInjectedCss("lds-badge-css", CSS);
  const classes = ["lds-badge", `lds-badge--${variant}`, square ? "lds-badge--square" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", {
    className: classes
  }, dot ? /*#__PURE__*/React.createElement("span", {
    className: "lds-badge__dot",
    "aria-hidden": "true"
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Badge.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.lds-check{
  position:relative; display:flex; align-items:center; gap:.5rem; width:fit-content;
  max-width:600px; margin-bottom:.4rem; cursor:pointer; white-space:normal;
  font-family:var(--font-body); font-size:var(--text-md); color:var(--text-default);
}
.lds-check input{
  appearance:none; position:relative; flex:0 0 18px; width:18px; height:18px; margin:0;
  background:#fff; border:1px solid var(--color-control-border); border-radius:var(--radius-xs);
  cursor:pointer;
}
.lds-check input[type=radio]{ border-radius:50%; }
.lds-check input:hover,.lds-check input:focus{ border:2px solid var(--color-control-on); outline:none; }
.lds-check input:checked{ background-color:var(--color-control-on); border-color:var(--color-control-on); }
.lds-check input:checked::after{
  content:""; position:absolute; top:9%; left:30%; width:25%; height:50%;
  border:1px solid #fff; border-width:0 3px 3px 0; border-radius:2px; transform:rotate(40deg);
}
.lds-check input[type=radio]:checked::after{
  top:50%; left:50%; width:8px; height:8px; border:0; border-radius:50%;
  background:#fff; transform:translate(-50%,-50%);
}
.lds-check input:disabled{ cursor:not-allowed; background:var(--color-base-lighter); border-color:var(--color-base-light); }
.lds-check--disabled{ cursor:not-allowed; color:var(--color-base); }
`;
function useInjectedCss(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id;
    el.textContent = css;
    document.head.appendChild(el);
  }, [id, css]);
}

/**
 * Checkbox — LEAF custom check / radio control (the "leaf_check" pattern):
 * an 18px square (or circle) that fills action-blue when selected.
 */
function Checkbox({
  label,
  type = "checkbox",
  disabled = false,
  className = "",
  ...rest
}) {
  useInjectedCss("lds-check-css", CSS);
  return /*#__PURE__*/React.createElement("label", {
    className: ["lds-check", disabled ? "lds-check--disabled" : "", className].filter(Boolean).join(" ")
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    disabled: disabled
  }, rest)), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.lds-field{ display:flex; flex-direction:column; max-width:30rem; margin-bottom:1rem; }
.lds-field__label{
  font-family:var(--font-body); font-weight:400; font-size:var(--text-sm);
  color:var(--text-default); margin-bottom:.25rem;
}
.lds-field__label .lds-req{ color:var(--color-secondary-dark); margin-left:.2em; }
.lds-field__hint{ font-size:var(--text-sm); color:var(--text-muted); margin:0 0 .25rem 0; }
.lds-field__input{
  display:block; width:100%; height:2.5rem; padding:.5rem; margin-top:.25rem;
  color:var(--color-ink); font-family:var(--font-body); font-size:var(--text-lg);
  background:#fff; border:1px solid var(--border-default); border-radius:var(--radius-xs);
}
.lds-field__input:focus{ outline:var(--focus-ring); outline-offset:0; }
.lds-field__input::placeholder{ color:var(--color-base); }
.lds-field--error .lds-field__input{ border-width:2px; border-color:var(--color-secondary-dark); }
.lds-field__error{
  display:flex; align-items:center; gap:.35rem; margin:.35rem 0 0 0;
  font-family:var(--font-display-bold); font-size:var(--text-sm); color:var(--color-secondary-dark);
}
textarea.lds-field__input{ height:8rem; resize:vertical; line-height:1.4; }
`;
function useInjectedCss(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id;
    el.textContent = css;
    document.head.appendChild(el);
  }, [id, css]);
}

/**
 * TextField — a labelled text input (USWDS form control) with optional
 * hint and error message. Renders a <textarea> when multiline.
 */
function TextField({
  label,
  id,
  hint,
  error,
  required = false,
  multiline = false,
  className = "",
  ...rest
}) {
  useInjectedCss("lds-field-css", CSS);
  const fieldId = id || (label ? label.toLowerCase().replace(/\s+/g, "-") : undefined);
  const Tag = multiline ? "textarea" : "input";
  return /*#__PURE__*/React.createElement("div", {
    className: ["lds-field", error ? "lds-field--error" : "", className].filter(Boolean).join(" ")
  }, label ? /*#__PURE__*/React.createElement("label", {
    className: "lds-field__label",
    htmlFor: fieldId
  }, label, required ? /*#__PURE__*/React.createElement("span", {
    className: "lds-req",
    "aria-hidden": "true"
  }, "*") : null) : null, hint ? /*#__PURE__*/React.createElement("span", {
    className: "lds-field__hint",
    id: fieldId ? fieldId + "-hint" : undefined
  }, hint) : null, /*#__PURE__*/React.createElement(Tag, _extends({
    className: "lds-field__input",
    id: fieldId,
    "aria-invalid": !!error
  }, rest)), error ? /*#__PURE__*/React.createElement("span", {
    className: "lds-field__error"
  }, /*#__PURE__*/React.createElement("i", {
    className: "fa-solid fa-circle-exclamation",
    "aria-hidden": "true"
  }), error) : null);
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.lds-card{
  background:var(--surface-card); border-radius:var(--radius-md);
  box-shadow:var(--shadow-sm); padding:1rem; color:var(--text-default);
  font-family:var(--font-body);
}
.lds-card--bordered{ box-shadow:var(--shadow-card); border:1px solid #ccc; border-radius:var(--radius-lg); }
.lds-card--flat{ box-shadow:none; border:1px solid var(--border-subtle); }
.lds-card--interactive{ cursor:pointer; transition:var(--transition-shadow); }
.lds-card--interactive:hover,.lds-card--interactive:focus{ box-shadow:var(--shadow-card-hover); outline:none; }
.lds-card__title{
  font-family:var(--font-display-medium); font-size:var(--text-xl);
  color:var(--color-base-darkest); margin:0 0 .5rem 0;
}
.lds-card__title a{ text-decoration:none; color:inherit; }
.lds-card__title a:hover{ text-decoration:underline; color:var(--text-link-hover); }
.lds-card__body{ font-size:var(--text-sm); line-height:1.45; color:var(--text-muted); }
.lds-card__body p{ margin:.2rem 0; }
.lds-card__footer{ margin-top:1rem; padding-top:.75rem; border-top:1px solid var(--border-subtle); display:flex; gap:.5rem; flex-wrap:wrap; }
`;
function useInjectedCss(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id;
    el.textContent = css;
    document.head.appendChild(el);
  }, [id, css]);
}

/**
 * Card — a white content panel with the LEAF soft elevation. Compose freely;
 * `title` and `footer` are optional conveniences.
 */
function Card({
  title,
  footer,
  variant = "default",
  interactive = false,
  children,
  className = "",
  ...rest
}) {
  useInjectedCss("lds-card-css", CSS);
  const classes = ["lds-card", variant !== "default" ? `lds-card--${variant}` : "", interactive ? "lds-card--interactive" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", _extends({
    className: classes,
    tabIndex: interactive ? 0 : undefined
  }, rest), title ? /*#__PURE__*/React.createElement("h3", {
    className: "lds-card__title"
  }, title) : null, /*#__PURE__*/React.createElement("div", {
    className: "lds-card__body"
  }, children), footer ? /*#__PURE__*/React.createElement("div", {
    className: "lds-card__footer"
  }, footer) : null);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/SideNav.jsx
try { (() => {
const CSS = `
.lds-sidenav{
  margin:0; padding:0; list-style:none; line-height:1.3;
  font-family:var(--font-display); font-size:var(--text-md);
  border-bottom:1px solid var(--border-subtle);
}
.lds-sidenav__item{ border-top:1px solid var(--border-subtle); }
.lds-sidenav__item > a{
  display:block; padding:.5em 1em; text-decoration:none; color:var(--text-muted);
}
.lds-sidenav__item > a:hover,.lds-sidenav__item > a:focus{
  color:var(--color-primary); background:var(--color-gray-4); outline:none;
}
.lds-sidenav__item > a.is-current{
  position:relative; color:var(--color-primary); font-family:var(--font-display-bold); font-weight:700;
}
.lds-sidenav__item > a.is-current::after{
  content:""; position:absolute; top:4px; bottom:4px; left:4px; width:4px;
  border-radius:4px; background:var(--color-primary);
}
.lds-sidenav__sublist{ margin:0; padding:0; list-style:none; }
.lds-sidenav__sublist .lds-sidenav__item > a{ padding-left:2rem; font-size:var(--text-sm); }
`;
function useInjectedCss(id, css) {
  React.useEffect(() => {
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id;
    el.textContent = css;
    document.head.appendChild(el);
  }, [id, css]);
}
function Item({
  item
}) {
  return /*#__PURE__*/React.createElement("li", {
    className: "lds-sidenav__item"
  }, /*#__PURE__*/React.createElement("a", {
    href: item.href || "#",
    className: item.current ? "is-current" : "",
    "aria-current": item.current ? "page" : undefined
  }, item.label), item.children && item.children.length ? /*#__PURE__*/React.createElement("ul", {
    className: "lds-sidenav__sublist"
  }, item.children.map((c, i) => /*#__PURE__*/React.createElement(Item, {
    key: i,
    item: c
  }))) : null);
}

/**
 * SideNav — the USWDS side navigation: a vertical list with hairline
 * dividers, hover wash, and a left-bar marker on the current item.
 */
function SideNav({
  items = [],
  className = ""
}) {
  useInjectedCss("lds-sidenav-css", CSS);
  return /*#__PURE__*/React.createElement("ul", {
    className: ["lds-sidenav", className].filter(Boolean).join(" ")
  }, items.map((item, i) => /*#__PURE__*/React.createElement(Item, {
    key: i,
    item: item
  })));
}
Object.assign(__ds_scope, { SideNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/SideNav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/request_portal/AdminScreen.jsx
try { (() => {
// LEAF Request Portal — Admin Panel (view_admin_menu.tpl).
// Grouped grid of leaf-admin-button tiles colored by USWDS background
// utilities (yellow / blue-cool / violet / green-cool / orange), each with
// a Font Awesome icon, a Public Sans Bold title, and a description.

const ADMIN_GROUPS = [{
  heading: "User Access",
  tone: "yellow",
  tiles: [{
    icon: "users",
    title: "User Access Groups",
    desc: "Modify users and groups"
  }, {
    icon: "user-group",
    title: "Service Chiefs",
    desc: "Review service chiefs and set backups"
  }, {
    icon: "table",
    title: "Access Matrix",
    desc: "Configure group access to tasks"
  }]
}, {
  heading: "Site Configuration",
  tone: "blue",
  tiles: [{
    icon: "diagram-project",
    title: "Workflow Editor",
    desc: "Edit flowcharts for workflows"
  }, {
    icon: "file-lines",
    title: "Form Editor",
    desc: "Create and modify forms"
  }, {
    icon: "book",
    title: "LEAF Library",
    desc: "Use a form made by the LEAF community"
  }, {
    icon: "gears",
    title: "Site Settings",
    desc: "Edit site name, time zone, and other labels"
  }, {
    icon: "sitemap",
    title: "Site Distribution",
    desc: "Deploy changes to subordinate sites"
  }]
}, {
  heading: "Admin Oversight Tools",
  tone: "violet",
  tiles: [{
    icon: "magnifying-glass",
    title: "Unresolved Requests",
    desc: "Examine potential delays"
  }, {
    icon: "clock-rotate-left",
    title: "Timeline Explorer",
    desc: "Analyze timeline data"
  }, {
    icon: "file-invoice",
    title: "Report Builder",
    desc: "Create custom reports"
  }, {
    icon: "chart-pie",
    title: "Data Visualizer",
    desc: "Analyze form responses"
  }]
}, {
  heading: "LEAF Developer Console",
  tone: "green",
  tiles: [{
    icon: "pen-to-square",
    title: "Template Editor",
    desc: "Edit HTML templates"
  }, {
    icon: "envelopes-bulk",
    title: "Email Template Editor",
    desc: "Add and edit email templates"
  }, {
    icon: "terminal",
    title: "LEAF Programmer",
    desc: "Advanced reports and custom pages"
  }, {
    icon: "folder-open",
    title: "File Manager",
    desc: "Upload custom images and documents"
  }, {
    icon: "arrows-rotate",
    title: "Sync Services",
    desc: "Update service listing from Org Chart"
  }, {
    icon: "database",
    title: "Update Database",
    desc: "Updates the system database, if available"
  }]
}, {
  heading: "Toolbox",
  tone: "orange",
  tiles: [{
    icon: "file-import",
    title: "Import Spreadsheet",
    desc: "Rows to requests, columns as fields"
  }, {
    icon: "list",
    title: "Mass Actions",
    desc: "Apply bulk actions to requests"
  }, {
    icon: "id-card",
    title: "New Account Updater",
    desc: "Update records with new account"
  }, {
    icon: "inbox",
    title: "Combined Inbox Editor",
    desc: "Edit combined inbox"
  }]
}];
const ADMIN_TONES = {
  yellow: {
    bg: "#faf3d1",
    icon: "#ad8b00",
    hover: "#f2e5a4"
  },
  blue: {
    bg: "#dae9ee",
    icon: "#2e6276",
    hover: "#cfe8ff"
  },
  violet: {
    bg: "#ebe3f9",
    icon: "#665190",
    hover: "#e0d3f5"
  },
  green: {
    bg: "#dbebde",
    icon: "#4d8055",
    hover: "#b7f5bd"
  },
  orange: {
    bg: "#f2e4d4",
    icon: "#a05a2c",
    hover: "#f1d5b4"
  }
};
function AdminTile({
  tile,
  tone
}) {
  const t = ADMIN_TONES[tone];
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      color: "#3d4551",
      display: "inline-flex",
      alignItems: "center",
      width: "21rem",
      height: "3.4rem",
      cursor: "pointer",
      margin: "0.6rem",
      padding: "0.5rem 0.5rem 0.4rem 0.6rem",
      textAlign: "left",
      boxShadow: hover ? "2px 2px 4px rgba(0,0,20,0.4)" : "2px 2px 2px rgba(0,0,20,0.2)",
      borderRadius: 4,
      border: "none",
      background: hover ? t.hover : t.bg,
      transition: "box-shadow .4s ease, background-color 1.4s ease"
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: `fa-solid fa-${tile.icon}`,
    "aria-hidden": "true",
    style: {
      fontSize: "1.7rem",
      width: "2.3rem",
      textAlign: "center",
      color: t.icon,
      flex: "0 0 auto",
      marginRight: ".4rem"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontSize: "1rem",
      lineHeight: "1.3rem",
      fontFamily: "var(--font-display-bold)",
      color: "var(--color-base-darker)"
    }
  }, tile.title), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontSize: "0.8rem",
      color: "var(--text-muted)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, tile.desc)));
}
function AdminScreen({
  data
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1088,
      margin: "0 auto",
      padding: "8px 8px 24px"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display-bold)",
      color: "var(--text-heading)",
      padding: "0 .6rem"
    }
  }, "Admin Panel"), ADMIN_GROUPS.map(g => /*#__PURE__*/React.createElement("section", {
    key: g.heading,
    style: {
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display-bold)",
      color: "var(--color-base-darker)",
      fontSize: 18,
      margin: "12px 0 2px",
      padding: "0 .6rem"
    }
  }, g.heading), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap"
    }
  }, g.tiles.map(tile => /*#__PURE__*/React.createElement(AdminTile, {
    key: tile.title,
    tile: tile,
    tone: g.tone
  }))))));
}
Object.assign(window, {
  AdminScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/request_portal/AdminScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/request_portal/HomeScreen.jsx
try { (() => {
// LEAF Request Portal — Home screen.
// Left column: colorful menu tiles (menuButtonSmall) exactly as view_homepage.tpl.
// Right: search box + records grid (LeafFormGrid) — Date / Title / Service / Status.
// Records owned by the current user get the #feffd1 yellow highlight.

const homeStyles = {
  wrap: {
    display: "flex",
    gap: 24,
    alignItems: "flex-start",
    flexWrap: "wrap",
    padding: "8px 16px"
  },
  tiles: {
    width: 320,
    flex: "0 0 auto"
  },
  tile: {
    display: "flex",
    alignItems: "center",
    width: 296,
    height: 60,
    cursor: "pointer",
    margin: "0 0 16px 0",
    padding: 2,
    boxShadow: "0 2px 6px #8e8e8e",
    transition: "box-shadow 0.3s ease",
    textDecoration: "none",
    border: "none"
  },
  tileIcon: {
    width: 58,
    height: 58,
    padding: "0 8px 0 2px",
    objectFit: "contain",
    flex: "0 0 auto"
  },
  tileText: {
    fontSize: 16,
    fontWeight: 700,
    lineHeight: 1.15,
    fontFamily: "var(--font-display-bold)"
  },
  tileDesc: {
    fontSize: 12,
    fontFamily: "var(--font-body)",
    lineHeight: 1.2
  },
  results: {
    flex: "1 1 480px",
    minWidth: 420
  },
  searchRow: {
    display: "flex",
    gap: 6,
    marginBottom: 12
  },
  search: {
    flex: 1,
    height: 38,
    padding: "0 10px",
    fontSize: 16,
    fontFamily: "var(--font-body)",
    border: "1px solid var(--border-default)",
    borderRadius: 2
  },
  table: {
    borderCollapse: "separate",
    borderSpacing: 0,
    width: "100%",
    fontFamily: "var(--font-body)"
  }
};
function Tile({
  bg,
  color = "#000",
  icon,
  label,
  desc,
  onClick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    style: {
      ...homeStyles.tile,
      backgroundColor: bg,
      color,
      boxShadow: hover ? "0 4px 6px 2px #8e8e8e" : "0 2px 6px #8e8e8e",
      outline: hover ? "2px dotted " + (color === "#fff" ? "#fff" : "#333") : "none"
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick: onClick
  }, /*#__PURE__*/React.createElement("img", {
    src: icon,
    alt: "",
    style: homeStyles.tileIcon
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: "left",
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      ...homeStyles.tileText,
      color
    }
  }, label), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      ...homeStyles.tileDesc,
      color
    }
  }, desc)));
}
function StatusCell({
  rec
}) {
  const map = {
    wait: {
      color: "#1b1b1b"
    },
    done: {
      color: "var(--color-success-dark)",
      weight: 700
    },
    error: {
      color: "#e00000",
      weight: 700
    }
  };
  const s = map[rec.tone] || map.wait;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      color: s.color,
      fontWeight: s.weight || 400
    }
  }, rec.status);
}
function HomeScreen({
  data,
  onNavigate
}) {
  const [q, setQ] = React.useState("");
  const records = data.records.filter(r => r.title.toLowerCase().includes(q.toLowerCase()) || String(r.id).includes(q) || r.service.toLowerCase().includes(q.toLowerCase()));
  const inboxCount = data.records.filter(r => r.tone === "wait").length;
  const cellBase = {
    border: "1px solid #000",
    borderTop: "none",
    borderLeft: "none",
    padding: 8,
    fontSize: 14,
    verticalAlign: "top"
  };
  const th = {
    background: "rgb(209,223,255)",
    borderTop: "1px solid #000",
    borderBottom: "1px solid #000",
    borderRight: "1px solid #000",
    borderLeft: "none",
    padding: "4px 8px",
    fontSize: 12,
    fontWeight: 400,
    textAlign: "left",
    fontFamily: "var(--font-body)"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: homeStyles.wrap
  }, /*#__PURE__*/React.createElement("div", {
    style: homeStyles.tiles
  }, /*#__PURE__*/React.createElement(Tile, {
    bg: "#2372b0",
    color: "#fff",
    icon: "../../assets/icons/document-new.svg",
    label: "New Request",
    desc: "Start a new request",
    onClick: () => onNavigate("new")
  }), /*#__PURE__*/React.createElement(Tile, {
    bg: inboxCount ? "#b6ef6d" : "#c9c9c9",
    icon: "../../assets/icons/folder-open.svg",
    label: "Inbox",
    desc: inboxCount ? "Review and apply actions to active requests" : "Your inbox is currently empty",
    onClick: () => onNavigate("inbox")
  }), /*#__PURE__*/React.createElement(Tile, {
    bg: "#7eb2b3",
    icon: "../../assets/icons/bookmark.svg",
    label: "Bookmarks",
    desc: "View saved links to requests",
    onClick: () => onNavigate("home")
  }), /*#__PURE__*/React.createElement(Tile, {
    bg: "#000",
    color: "#fff",
    icon: "../../assets/icons/x-office-spreadsheet.svg",
    label: "Report Builder",
    desc: "Create custom reports",
    onClick: () => onNavigate("reports")
  })), /*#__PURE__*/React.createElement("div", {
    style: homeStyles.results
  }, /*#__PURE__*/React.createElement("div", {
    style: homeStyles.searchRow
  }, /*#__PURE__*/React.createElement("input", {
    style: homeStyles.search,
    placeholder: "Search requests by title, ID, or service\u2026",
    value: q,
    onChange: e => setQ(e.target.value),
    "aria-label": "Search requests"
  }), /*#__PURE__*/React.createElement("button", {
    className: "lds-btn",
    style: {
      minWidth: 0
    },
    onClick: () => {}
  }, /*#__PURE__*/React.createElement("i", {
    className: "fa-solid fa-magnifying-glass",
    "aria-hidden": "true"
  }), " Search")), /*#__PURE__*/React.createElement("table", {
    style: homeStyles.table,
    className: "leaf_grid"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      ...th,
      width: 70
    }
  }, "Date"), /*#__PURE__*/React.createElement("th", {
    style: th
  }, "Title"), /*#__PURE__*/React.createElement("th", {
    style: {
      ...th,
      width: 130
    }
  }, "Service"), /*#__PURE__*/React.createElement("th", {
    style: {
      ...th,
      width: 180
    }
  }, "Status"))), /*#__PURE__*/React.createElement("tbody", {
    style: {
      background: "#fff"
    }
  }, records.map(r => {
    const hl = r.mine ? {
      backgroundColor: "#feffd1"
    } : null;
    return /*#__PURE__*/React.createElement("tr", {
      key: r.id,
      style: {
        cursor: "pointer"
      },
      onClick: () => onNavigate("record", r.id)
    }, /*#__PURE__*/React.createElement("td", {
      style: {
        ...cellBase,
        whiteSpace: "nowrap",
        ...hl
      }
    }, r.date), /*#__PURE__*/React.createElement("td", {
      style: cellBase
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-block",
        padding: 4,
        marginRight: 6,
        fontSize: 18,
        fontWeight: 700,
        background: r.priority === -10 ? "#FF4040" : "#000",
        color: r.priority === -10 ? "#000" : "#fff",
        float: "left",
        textDecoration: "none"
      }
    }, r.id), /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => e.preventDefault(),
      style: {
        fontSize: "1.05rem",
        color: "var(--text-link)"
      }
    }, r.title), r.priority === -10 && /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#c00000",
        fontWeight: 700
      }
    }, " (\xA0Emergency\xA0)"), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        color: "#707070"
      }
    }, r.types)), /*#__PURE__*/React.createElement("td", {
      style: {
        ...cellBase,
        ...hl
      }
    }, r.service), /*#__PURE__*/React.createElement("td", {
      style: {
        ...cellBase,
        ...hl
      }
    }, /*#__PURE__*/React.createElement(StatusCell, {
      rec: r
    })));
  }), records.length === 0 && /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    style: cellBase,
    colSpan: 4
  }, "No records match \u201C", q, "\u201D."))))));
}
Object.assign(window, {
  HomeScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/request_portal/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/request_portal/InboxScreen.jsx
try { (() => {
// LEAF Request Portal — Inbox (report.php?a=LEAF_Inbox&organizeByRole).
// Records awaiting the current user's action, grouped by the role/step they
// hold. Each group is a leaf_grid with an "Action" column ("Take Action")
// that opens a workflow action dialog (LeafWorkflow → approve / return).

function InboxScreen({
  data,
  onNavigate
}) {
  const {
    Button,
    Badge
  } = window.LEAFDesignSystem_28d2bd;
  const [dialog, setDialog] = React.useState(null); // record being acted on
  const [done, setDone] = React.useState({}); // recordID -> "Approved" | "Returned"
  const [comment, setComment] = React.useState("");
  const total = data.inbox.reduce((n, g) => n + g.items.filter(it => !done[it.id]).length, 0);
  const th = {
    background: "rgb(209,223,255)",
    borderTop: "1px solid #000",
    borderBottom: "1px solid #000",
    borderRight: "1px solid #000",
    borderLeft: "none",
    padding: "4px 8px",
    fontSize: 12,
    fontWeight: 400,
    textAlign: "left",
    fontFamily: "var(--font-body)"
  };
  const td = {
    border: "1px solid #000",
    borderTop: "none",
    borderLeft: "none",
    padding: 8,
    fontSize: 14,
    verticalAlign: "top"
  };
  const act = (rec, action) => {
    setDialog(rec);
    setComment("");
  };
  const apply = action => {
    setDone(d => ({
      ...d,
      [dialog.id]: action
    }));
    setDialog(null);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "8px 16px 24px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/folder-open.svg",
    width: "34",
    height: "34",
    alt: ""
  }), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display-bold)",
      color: "var(--text-heading)",
      margin: 0,
      fontSize: 22,
      whiteSpace: "nowrap"
    }
  }, "Inbox"), /*#__PURE__*/React.createElement(Badge, {
    variant: "primary"
  }, total, " awaiting you")), total === 0 && /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--text-muted)"
    }
  }, "You have no requests awaiting your review. Nicely done."), data.inbox.map(group => {
    const pending = group.items.filter(it => !done[it.id]);
    return /*#__PURE__*/React.createElement("section", {
      key: group.role,
      style: {
        marginBottom: 22
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "#003a6b",
        color: "#fff",
        padding: "4px 10px",
        fontFamily: "var(--font-display-bold)",
        fontSize: 15
      }
    }, group.role, " ", /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 400,
        opacity: .85
      }
    }, "\xB7 ", pending.length, " item", pending.length !== 1 ? "s" : "")), /*#__PURE__*/React.createElement("table", {
      style: {
        borderCollapse: "separate",
        borderSpacing: 0,
        width: "100%",
        margin: "2px 0"
      },
      className: "leaf_grid"
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
      style: {
        ...th,
        width: 120
      }
    }, "Action"), /*#__PURE__*/React.createElement("th", {
      style: th
    }, "Title"), /*#__PURE__*/React.createElement("th", {
      style: {
        ...th,
        width: 150
      }
    }, "Initiator"), /*#__PURE__*/React.createElement("th", {
      style: {
        ...th,
        width: 150
      }
    }, "Time in step"))), /*#__PURE__*/React.createElement("tbody", {
      style: {
        background: "#fff"
      }
    }, group.items.map(it => {
      const status = done[it.id];
      return /*#__PURE__*/React.createElement("tr", {
        key: it.id
      }, /*#__PURE__*/React.createElement("td", {
        style: td
      }, status ? /*#__PURE__*/React.createElement(Badge, {
        variant: status === "Approved" ? "success" : "error",
        dot: true
      }, status) : /*#__PURE__*/React.createElement("span", {
        tabIndex: 0,
        role: "button",
        onClick: () => act(it),
        style: {
          display: "inline-block",
          cursor: "pointer",
          padding: "4px 8px",
          fontSize: 13,
          background: "#e8f2ff",
          border: "1px solid #000",
          color: "#000"
        }
      }, "Take Action")), /*#__PURE__*/React.createElement("td", {
        style: td
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          display: "inline-block",
          padding: 4,
          marginRight: 6,
          fontSize: 16,
          fontWeight: 700,
          background: it.priority === -10 ? "#FF4040" : "#000",
          color: it.priority === -10 ? "#000" : "#fff",
          float: "left"
        }
      }, it.id), /*#__PURE__*/React.createElement("a", {
        href: "#",
        onClick: e => {
          e.preventDefault();
          onNavigate("record", it.id);
        },
        style: {
          color: "var(--text-link)"
        }
      }, it.title), it.priority === -10 && /*#__PURE__*/React.createElement("span", {
        style: {
          color: "#c00000",
          fontWeight: 700
        }
      }, " (\xA0Emergency\xA0)"), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 11,
          color: "#707070"
        }
      }, it.types)), /*#__PURE__*/React.createElement("td", {
        style: td
      }, it.initiator), /*#__PURE__*/React.createElement("td", {
        style: td
      }, it.days, " day", it.days !== 1 ? "s" : ""));
    }))));
  }), dialog && /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    style: {
      position: "fixed",
      inset: 0,
      background: "rgba(0,0,20,.4)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: 9999
    },
    onClick: () => setDialog(null)
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: "#fff",
      width: 460,
      maxWidth: "92vw",
      boxShadow: "0 0 5px 1px rgba(0,0,25,.25)",
      borderRadius: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--color-primary-surface)",
      borderBottom: "1px solid var(--color-primary-border)",
      padding: "10px 14px",
      fontFamily: "var(--font-display-bold)",
      color: "var(--color-base-darkest)"
    }
  }, "Apply Action to #", dialog.id), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 0,
      color: "var(--text-muted)"
    }
  }, dialog.title), /*#__PURE__*/React.createElement("label", {
    className: "lds-field__label",
    style: {
      display: "block",
      marginBottom: 4
    }
  }, "Comment (optional)"), /*#__PURE__*/React.createElement("textarea", {
    value: comment,
    onChange: e => setComment(e.target.value),
    rows: 3,
    style: {
      width: "100%",
      boxSizing: "border-box",
      padding: 8,
      fontFamily: "var(--font-body)",
      fontSize: 15,
      border: "1px solid var(--border-default)",
      borderRadius: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginTop: 14,
      justifyContent: "flex-end"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    onClick: () => setDialog(null)
  }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconBefore: "arrow-right",
    onClick: () => apply("Returned")
  }, "Return"), /*#__PURE__*/React.createElement(Button, {
    variant: "success",
    iconBefore: "check",
    onClick: () => apply("Approved")
  }, "Approve"))))));
}
Object.assign(window, {
  InboxScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/request_portal/InboxScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/request_portal/LoginScreen.jsx
try { (() => {
// LEAF Request Portal — Login (login.tpl). Minimal VA SSO-style entry.
function LoginScreen({
  data,
  onNavigate
}) {
  const {
    Button
  } = window.LEAFDesignSystem_28d2bd;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "center",
      padding: "48px 16px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      border: "1px solid #ccc",
      borderRadius: 5,
      boxShadow: "0 2px 3px #a7a9aa",
      padding: 32,
      width: 420,
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/brand/VA_icon_small.png",
    width: "64",
    height: "64",
    alt: "VA seal",
    style: {
      marginBottom: 12
    }
  }), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display-bold)",
      color: "var(--text-heading)",
      margin: "0 0 4px"
    }
  }, data.site.title), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--text-muted)",
      marginTop: 0
    }
  }, data.site.city), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--color-primary-surface)",
      border: "1px solid var(--color-primary-border)",
      borderRadius: 4,
      padding: "10px 12px",
      fontSize: 14,
      color: "var(--color-base-darker)",
      margin: "16px 0",
      textAlign: "left"
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: "fa-solid fa-circle-info",
    style: {
      color: "var(--color-primary)",
      marginRight: 6
    },
    "aria-hidden": "true"
  }), "You'll be signed in using your VA Single Sign-On (SSO) credentials."), /*#__PURE__*/React.createElement(Button, {
    block: true,
    onClick: () => onNavigate("home")
  }, "Sign in with VA SSO"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: "var(--text-muted)",
      marginTop: 16
    }
  }, "Authorized use only. Activity may be monitored.")));
}
Object.assign(window, {
  LoginScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/request_portal/LoginScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/request_portal/NewRequestScreen.jsx
try { (() => {
// LEAF Request Portal — New Request screen.
// Step 1: pick a request type (initial_form.tpl category list).
// Step 2: fill the form (Service select + fields), then submit → confirmation.
// Composes the design-system TextField, Checkbox, Button, Alert components.

function NewRequestScreen({
  data,
  onNavigate
}) {
  const {
    TextField,
    Checkbox,
    Button,
    Alert
  } = window.LEAFDesignSystem_28d2bd;
  const [cat, setCat] = React.useState(null);
  const [submitted, setSubmitted] = React.useState(false);
  const card = {
    background: "#fff",
    border: "1px solid #ccc",
    borderRadius: 5,
    boxShadow: "0 2px 3px #a7a9aa",
    padding: 16,
    maxWidth: 760,
    margin: "0 auto"
  };
  if (submitted) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "16px",
        maxWidth: 760,
        margin: "0 auto"
      }
    }, /*#__PURE__*/React.createElement(Alert, {
      variant: "success",
      title: "Your request has been submitted"
    }, "Tracking #VHA-20483 \u2014 routed to your supervisor for approval. You'll be notified when an action is taken."), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 16,
        display: "flex",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Button, {
      onClick: () => onNavigate("record", 20482)
    }, "View request"), /*#__PURE__*/React.createElement(Button, {
      variant: "outline",
      onClick: () => onNavigate("home")
    }, "Back to homepage")));
  }
  if (!cat) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "8px 16px",
        maxWidth: 820,
        margin: "0 auto"
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        fontFamily: "var(--font-display-bold)",
        color: "var(--text-heading)",
        marginBottom: 4
      }
    }, "Start a new request"), /*#__PURE__*/React.createElement("p", {
      style: {
        color: "var(--text-muted)",
        marginTop: 0
      }
    }, "Select the type of request you'd like to create."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 12,
        marginTop: 12
      }
    }, data.categories.map(c => /*#__PURE__*/React.createElement("button", {
      key: c.id,
      onClick: () => setCat(c),
      style: {
        display: "flex",
        alignItems: "center",
        gap: 14,
        textAlign: "left",
        cursor: "pointer",
        background: "#fff",
        border: "1px solid #ccc",
        borderRadius: 5,
        boxShadow: "0 2px 3px #a7a9aa",
        padding: 14,
        transition: "box-shadow .4s ease"
      },
      onMouseEnter: e => e.currentTarget.style.boxShadow = "0 12px 9px #949191",
      onMouseLeave: e => e.currentTarget.style.boxShadow = "0 2px 3px #a7a9aa"
    }, /*#__PURE__*/React.createElement("img", {
      src: "../../assets/icons/document-new.svg",
      width: "40",
      height: "40",
      alt: ""
    }), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "block",
        fontFamily: "var(--font-display-medium)",
        fontSize: 18,
        color: "var(--color-base-darkest)"
      }
    }, c.name), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: "var(--text-muted)"
      }
    }, c.desc)), /*#__PURE__*/React.createElement("i", {
      className: "fa-solid fa-chevron-right",
      style: {
        marginLeft: "auto",
        color: "var(--color-primary)"
      },
      "aria-hidden": "true"
    })))));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "8px 16px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: card
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setCat(null),
    className: "lds-iconbtn lds-iconbtn--ghost",
    "aria-label": "Back",
    style: {
      flex: "0 0 auto"
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: "fa-solid fa-chevron-left",
    "aria-hidden": "true"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display-bold)",
      color: "var(--text-heading)",
      margin: 0,
      fontSize: 20,
      lineHeight: 1.1
    }
  }, cat.name), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--text-muted)",
      margin: "2px 0 0"
    }
  }, cat.desc))), /*#__PURE__*/React.createElement("hr", {
    style: {
      border: 0,
      borderTop: "1px solid var(--border-subtle)",
      margin: "0 0 20px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "0 28px"
    }
  }, /*#__PURE__*/React.createElement(TextField, {
    label: "Requestor name",
    required: true,
    defaultValue: data.site.user
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Service / Section",
    required: true,
    defaultValue: "Cardiology"
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "First day of leave",
    type: "date"
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Last day of leave",
    type: "date"
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Total hours requested",
    type: "number",
    defaultValue: "40"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    className: "lds-field__label",
    style: {
      display: "block",
      marginBottom: 6
    }
  }, "Type of leave"), /*#__PURE__*/React.createElement(Checkbox, {
    type: "radio",
    name: "leave",
    label: "Annual leave",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Checkbox, {
    type: "radio",
    name: "leave",
    label: "Sick leave"
  }), /*#__PURE__*/React.createElement(Checkbox, {
    type: "radio",
    name: "leave",
    label: "Leave without pay"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(TextField, {
    label: "Justification / notes",
    multiline: true,
    hint: "Be specific. This is visible to all approvers.",
    defaultValue: "Pre-planned family travel. Coverage confirmed with Dr. Smith for all clinic days."
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: "Email me when an action is taken on this request",
    defaultChecked: true
  })), /*#__PURE__*/React.createElement("hr", {
    style: {
      border: 0,
      borderTop: "1px solid var(--border-subtle)",
      margin: "16px 0"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "success",
    iconBefore: "check",
    onClick: () => setSubmitted(true)
  }, "Submit request"), /*#__PURE__*/React.createElement(Button, {
    variant: "base",
    onClick: () => onNavigate("home")
  }, "Save & finish later"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    onClick: () => onNavigate("home")
  }, "Cancel"))));
}
Object.assign(window, {
  NewRequestScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/request_portal/NewRequestScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/request_portal/PortalChrome.jsx
try { (() => {
// LEAF Request Portal — page chrome (header + nav menu + footer).
// Mirrors main.tpl / menu.tpl and #header styling from style.css:
// light blue→white gradient bar, VA seal, blue city label, black title,
// right-aligned login + "Do not enter PHI/PII" notice, and the menu row.

const portalChromeStyles = {
  header: {
    position: "relative",
    fontFamily: "var(--font-display-bold)",
    background: "linear-gradient(180deg, #dce8fb 0%, #ffffff 72%)",
    height: 80,
    borderBottom: "2px solid #5a79a5",
    marginBottom: 4,
    textAlign: "left"
  },
  seal: {
    position: "absolute",
    left: 8,
    top: 6,
    width: 68,
    height: 68
  },
  label: {
    position: "absolute",
    color: "#17008a",
    left: 90,
    top: 40,
    fontSize: 15,
    fontFamily: "var(--font-display)"
  },
  desc: {
    position: "absolute",
    margin: 0,
    fontSize: 21,
    color: "#000",
    left: 90,
    top: 10,
    fontFamily: "var(--font-display-bold)",
    fontWeight: 700,
    whiteSpace: "nowrap",
    lineHeight: 1.1
  },
  help: {
    position: "absolute",
    top: 8,
    right: 12,
    fontSize: 12,
    fontWeight: "normal",
    display: "flex",
    gap: 8,
    alignItems: "center"
  },
  phi: {
    background: "#9d0000",
    color: "#fff",
    fontWeight: 700,
    padding: "2px 6px",
    fontSize: 12
  },
  login: {
    position: "absolute",
    top: 30,
    right: 12,
    fontSize: 12,
    fontWeight: "normal",
    color: "#1b1b1b"
  },
  menu: {
    position: "absolute",
    bottom: 4,
    right: 10,
    fontSize: 12,
    fontWeight: "normal"
  }
};
function PortalHeader({
  site,
  route,
  onNavigate
}) {
  const navBtn = active => ({
    display: "inline-flex",
    alignItems: "center",
    gap: 4,
    padding: "4px 8px",
    border: "none",
    cursor: "pointer",
    background: active ? "#2372b0" : "transparent",
    color: active ? "#fff" : "#000",
    textDecoration: "none",
    fontFamily: "var(--font-body)",
    fontSize: 13,
    borderRadius: 3
  });
  return /*#__PURE__*/React.createElement("header", {
    style: portalChromeStyles.header
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate("home");
    },
    style: {
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/brand/VA_icon_small.png",
    style: portalChromeStyles.seal,
    alt: "VA seal, U.S. Department of Veterans Affairs"
  }), /*#__PURE__*/React.createElement("span", {
    style: portalChromeStyles.label
  }, site.city), /*#__PURE__*/React.createElement("h1", {
    style: portalChromeStyles.desc
  }, site.title)), /*#__PURE__*/React.createElement("span", {
    style: portalChromeStyles.help
  }, /*#__PURE__*/React.createElement("span", {
    style: portalChromeStyles.phi
  }, "Do not enter PHI/PII.")), /*#__PURE__*/React.createElement("span", {
    style: portalChromeStyles.login
  }, "Welcome, ", /*#__PURE__*/React.createElement("b", null, site.user), " \xA0|\xA0", /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate("login");
    },
    style: {
      color: "var(--text-link)"
    }
  }, " Sign out")), /*#__PURE__*/React.createElement("nav", {
    style: portalChromeStyles.menu,
    "aria-label": "LEAF site main menu"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      gap: 4
    }
  }, route !== "home" && /*#__PURE__*/React.createElement("button", {
    style: navBtn(false),
    onClick: () => onNavigate("home")
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/go-home.svg",
    width: "16",
    alt: ""
  }), "Home"), /*#__PURE__*/React.createElement("button", {
    style: navBtn(false)
  }, "Links", /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, "\u25BE")), /*#__PURE__*/React.createElement("button", {
    style: navBtn(false)
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/help-browser.svg",
    width: "16",
    alt: ""
  }), "Help", /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, "\u25BE")), /*#__PURE__*/React.createElement("button", {
    style: navBtn(route === "admin"),
    onClick: () => onNavigate("admin")
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/applications-system.svg",
    width: "16",
    alt: ""
  }), "Admin Panel"))));
}
function PortalFooter() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      textAlign: "right",
      padding: 8,
      fontSize: 10,
      color: "var(--text-muted)",
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: "var(--text-muted)",
      textDecoration: "none"
    }
  }, "LEAF \u2014 Light Electronic Action Framework", /*#__PURE__*/React.createElement("br", null), "Version 5.0 r20260608"));
}
Object.assign(window, {
  PortalHeader,
  PortalFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/request_portal/PortalChrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/request_portal/RecordScreen.jsx
try { (() => {
// LEAF Request Portal — Record view screen (print_form.tpl).
// Two columns: the form responses (mainform) + a workflow progress sidebar,
// with a right-hand Tools toolbar. Composes Badge + Button from the system.

function RecordScreen({
  data,
  onNavigate
}) {
  const {
    Badge,
    Button
  } = window.LEAFDesignSystem_28d2bd;
  const d = data.detail;
  const panel = {
    background: "#fff",
    border: "1px solid #ccc",
    borderRadius: 4,
    boxShadow: "0 1px 3px rgba(0,0,0,.2)"
  };
  const tool = {
    display: "flex",
    alignItems: "center",
    gap: 8,
    width: "100%",
    textAlign: "left",
    padding: "8px 10px",
    marginBottom: 6,
    cursor: "pointer",
    background: "#fff",
    border: "1px solid var(--border-subtle)",
    borderRadius: 3,
    fontFamily: "var(--font-body)",
    fontSize: 14
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "8px 16px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      flexWrap: "wrap",
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      background: "#000",
      color: "#fff",
      fontWeight: 700,
      fontSize: 18,
      padding: "4px 10px",
      flex: "0 0 auto"
    }
  }, "#", d.id), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display-bold)",
      color: "var(--text-heading)",
      margin: 0,
      fontSize: 20,
      lineHeight: 1.15
    }
  }, d.title), /*#__PURE__*/React.createElement(Badge, {
    variant: "warning",
    dot: true
  }, "Pending Supervisor Approval")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 260px",
      gap: 20,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      ...panel,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--color-base-darkest)",
      color: "#fff",
      padding: "8px 12px",
      fontFamily: "var(--font-display-bold)",
      borderRadius: "4px 4px 0 0"
    }
  }, "Workflow progress"), /*#__PURE__*/React.createElement("ol", {
    style: {
      listStyle: "none",
      margin: 0,
      padding: 12,
      display: "flex",
      flexDirection: "column",
      gap: 2
    }
  }, d.workflow.map((w, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "8px 6px",
      background: w.current ? "var(--color-primary-surface)" : "transparent",
      borderRadius: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: "0 0 22px",
      width: 22,
      height: 22,
      borderRadius: "50%",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 12,
      color: "#fff",
      background: w.done ? "var(--color-success)" : w.current ? "var(--color-primary)" : "var(--color-base-light)"
    }
  }, w.done ? /*#__PURE__*/React.createElement("i", {
    className: "fa-solid fa-check",
    "aria-hidden": "true"
  }) : i + 1), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontFamily: w.current ? "var(--font-display-bold)" : "var(--font-body)",
      fontSize: 14,
      color: "var(--text-default)"
    }
  }, w.step), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text-muted)"
    }
  }, w.who)), w.done && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text-muted)"
    }
  }, w.date), w.current && /*#__PURE__*/React.createElement(Badge, {
    variant: "info"
  }, "Current step"))))), /*#__PURE__*/React.createElement("div", {
    style: panel
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "10px 16px",
      borderBottom: "1px solid var(--border-subtle)",
      fontFamily: "var(--font-display-bold)",
      color: "var(--color-base-darkest)"
    }
  }, d.type), /*#__PURE__*/React.createElement("dl", {
    style: {
      margin: 0,
      padding: "8px 16px 16px"
    }
  }, d.fields.map((f, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: "10px 0",
      borderBottom: i < d.fields.length - 1 ? "1px solid var(--border-subtle)" : "none"
    }
  }, /*#__PURE__*/React.createElement("dt", {
    style: {
      fontFamily: "var(--font-display-bold)",
      fontSize: 14,
      color: "var(--text-default)"
    }
  }, f.label), /*#__PURE__*/React.createElement("dd", {
    style: {
      margin: "4px 0 0",
      fontFamily: "var(--font-mono)",
      fontSize: 15,
      color: "rgba(0,0,0,.82)"
    }
  }, f.value))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      display: "flex",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "success",
    iconBefore: "check"
  }, "Approve"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconBefore: "arrow-right"
  }, "Return for edits"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    onClick: () => onNavigate("home")
  }, "Back to homepage"))), /*#__PURE__*/React.createElement("aside", {
    style: {
      ...panel,
      padding: 12
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: "0 0 10px",
      fontFamily: "var(--font-display-bold)",
      color: "var(--color-base-darkest)",
      fontSize: 16
    }
  }, "Tools"), /*#__PURE__*/React.createElement("button", {
    style: tool
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/edit-find-replace.svg",
    width: "22",
    alt: ""
  }), "Edit this form"), /*#__PURE__*/React.createElement("button", {
    style: tool
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/appointment.svg",
    width: "22",
    alt: ""
  }), "View history"), /*#__PURE__*/React.createElement("button", {
    style: tool
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/internet-mail.svg",
    width: "22",
    alt: ""
  }), "Write email"), /*#__PURE__*/React.createElement("button", {
    style: tool
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/printer.svg",
    width: "22",
    alt: ""
  }), "Print"), /*#__PURE__*/React.createElement("button", {
    style: tool
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/bookmark.svg",
    width: "22",
    alt: ""
  }), "Bookmark"))));
}
Object.assign(window, {
  RecordScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/request_portal/RecordScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/request_portal/ReportBuilderScreen.jsx
try { (() => {
// LEAF Request Portal — Report Builder (view_reports.tpl).
// Step 1: develop a search filter (uses the AdvancedSearch component).
// Step 2: select data columns (grouped checkboxes). Generate → results grid.

const REPORT_COLUMNS = [{
  group: "General",
  cols: [{
    id: "title",
    label: "Title of Request",
    on: true
  }, {
    id: "service",
    label: "Service"
  }, {
    id: "type",
    label: "Type of Request"
  }, {
    id: "status",
    label: "Current Status",
    on: true
  }, {
    id: "initiator",
    label: "Initiator",
    on: true
  }, {
    id: "actionButton",
    label: "Action Button"
  }]
}, {
  group: "History",
  cols: [{
    id: "comment_history",
    label: "Comment History"
  }, {
    id: "approval_history",
    label: "Approval History"
  }, {
    id: "days_last_action",
    label: "Days Since Last Action"
  }, {
    id: "days_last_step",
    label: "Days Since Last Step Movement"
  }]
}, {
  group: "Action Dates",
  cols: [{
    id: "dateInitiated",
    label: "Date Request Initiated",
    on: true
  }, {
    id: "dateResolved",
    label: "Date Request Resolved"
  }, {
    id: "resolvedBy",
    label: "Resolved By"
  }, {
    id: "dateCancelled",
    label: "Date Request Cancelled"
  }, {
    id: "destruction",
    label: "Date of Scheduled Destruction"
  }]
}];
const REPORT_RESULTS = [{
  id: 20482,
  title: "Annual Leave — June 24–28",
  status: "Pending Supervisor",
  initiator: "Veteran, Jane Q.",
  date: "6/6/2026",
  tone: "wait"
}, {
  id: 20468,
  title: "Conference travel — ACC 2026",
  status: "Pending Supervisor",
  initiator: "Patel, Anil",
  date: "6/4/2026",
  tone: "wait"
}, {
  id: 20461,
  title: "Replacement pulse oximeters (x4)",
  status: "Approved",
  initiator: "Lowe, Sam",
  date: "6/1/2026",
  tone: "done"
}, {
  id: 20457,
  title: "Telework — 2 days/week",
  status: "Returned for edits",
  initiator: "Reyes, Mia",
  date: "5/31/2026",
  tone: "error"
}, {
  id: 20448,
  title: "Annual leave — July 4 week",
  status: "Approved",
  initiator: "Okafor, Joy",
  date: "5/27/2026",
  tone: "done"
}];
function ReportBuilderScreen() {
  const ns = window.LEAFDesignSystem_28d2bd;
  const {
    Button,
    Badge
  } = ns;
  // AdvancedSearch may briefly be unavailable while the bundle propagates; fall
  // back to a plain search input so the wizard never fails to render.
  const AdvancedSearch = ns.AdvancedSearch || function FallbackSearch({
    placeholder,
    onSearch
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("input", {
      type: "text",
      placeholder: placeholder,
      "aria-label": "Search",
      style: {
        flex: 1,
        padding: "5px 8px",
        border: "1px solid #000",
        fontFamily: "var(--font-body)",
        fontSize: 16
      },
      onKeyDown: e => {
        if (e.key === "Enter" && onSearch) onSearch(e.target.value);
      }
    }), /*#__PURE__*/React.createElement("button", {
      className: "lds-btn",
      style: {
        minWidth: 0
      }
    }, "Search"));
  };
  const [step, setStep] = React.useState(1);
  const [cols, setCols] = React.useState(() => {
    const init = {};
    REPORT_COLUMNS.forEach(g => g.cols.forEach(c => {
      if (c.on) init[c.id] = true;
    }));
    return init;
  });
  const toggle = id => setCols(c => ({
    ...c,
    [id]: !c[id]
  }));
  const chosen = REPORT_COLUMNS.flatMap(g => g.cols).filter(c => cols[c.id]);
  const stepHeader = (n, label, color) => /*#__PURE__*/React.createElement("div", {
    style: {
      background: color,
      color: "#fff",
      padding: "6px 12px",
      fontSize: 20,
      fontWeight: 700,
      fontFamily: "var(--font-display-bold)"
    }
  }, "Step ", n, ": ", label);
  const panel = {
    background: "#fff",
    border: "1px solid #000",
    margin: "0 auto 20px",
    maxWidth: 920
  };
  const th = {
    background: "rgb(209,223,255)",
    borderTop: "1px solid #000",
    borderBottom: "1px solid #000",
    borderRight: "1px solid #000",
    padding: "4px 8px",
    fontSize: 12,
    fontWeight: 400,
    textAlign: "left"
  };
  const td = {
    border: "1px solid #000",
    borderTop: "none",
    borderLeft: "none",
    padding: 8,
    fontSize: 14
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "8px 16px 28px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 920,
      margin: "0 auto 14px",
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/icons/x-office-spreadsheet.svg",
    width: "30",
    height: "30",
    alt: ""
  }), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display-bold)",
      color: "var(--text-heading)",
      margin: 0,
      fontSize: 22,
      whiteSpace: "nowrap"
    }
  }, "Report Builder")), /*#__PURE__*/React.createElement("div", {
    style: panel
  }, stepHeader(1, "Develop search filter", "#003a6b"), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14
    }
  }, /*#__PURE__*/React.createElement(AdvancedSearch, {
    placeholder: "Search records to include\u2026",
    onApply: () => setStep(2),
    onSearch: () => setStep(2)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    onClick: () => setStep(2),
    iconAfter: "arrow-right"
  }, "Continue to columns")))), step >= 2 && /*#__PURE__*/React.createElement("div", {
    style: panel
  }, stepHeader(2, "Select data columns", "#0059a4"), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 18
    }
  }, REPORT_COLUMNS.map(g => /*#__PURE__*/React.createElement("div", {
    key: g.group
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display-bold)",
      fontSize: 13,
      color: "var(--color-base-darker)",
      borderBottom: "1px solid #e0e0e0",
      paddingBottom: 4,
      marginBottom: 6
    }
  }, g.group), g.cols.map(c => /*#__PURE__*/React.createElement("label", {
    key: c.id,
    className: "lds-check",
    style: {
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: !!cols[c.id],
    onChange: () => toggle(c.id)
  }), /*#__PURE__*/React.createElement("span", null, c.label)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setStep(3),
    style: {
      cursor: "pointer",
      fontSize: 18,
      fontFamily: "var(--font-display-bold)",
      color: "#000",
      background: "#e8f2ff",
      border: "1px solid #000",
      padding: "10px 24px",
      boxShadow: "0 2px 6px #8e8e8e"
    }
  }, "Generate Report ", /*#__PURE__*/React.createElement("i", {
    className: "fa-solid fa-table",
    "aria-hidden": "true"
  }))))), step >= 3 && /*#__PURE__*/React.createElement("div", {
    style: panel
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "10px 12px",
      borderBottom: "1px solid #000"
    }
  }, /*#__PURE__*/React.createElement("input", {
    defaultValue: "Untitled Report",
    "aria-label": "Report title",
    style: {
      fontSize: 22,
      fontFamily: "var(--font-display-bold)",
      border: "none",
      borderBottom: "1px dashed #aaa",
      flex: 1,
      padding: "2px 0"
    }
  }), /*#__PURE__*/React.createElement(Badge, {
    variant: "neutral"
  }, REPORT_RESULTS.length, " records"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "outline",
    iconBefore: "download"
  }, "Export")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 12,
      overflowX: "auto"
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      borderCollapse: "separate",
      borderSpacing: 0,
      width: "100%"
    },
    className: "leaf_grid"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, chosen.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.id,
    style: th
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", {
    style: {
      background: "#fff"
    }
  }, REPORT_RESULTS.map(r => /*#__PURE__*/React.createElement("tr", {
    key: r.id
  }, chosen.map(c => {
    let content = null;
    if (c.id === "title") content = /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", {
      style: {
        background: "#000",
        color: "#fff",
        padding: "1px 5px",
        marginRight: 6
      }
    }, r.id), r.title);else if (c.id === "status") content = /*#__PURE__*/React.createElement("span", {
      style: {
        color: r.tone === "done" ? "var(--color-success-dark)" : r.tone === "error" ? "#e00000" : "#1b1b1b",
        fontWeight: r.tone === "wait" ? 400 : 700
      }
    }, r.status);else if (c.id === "initiator") content = r.initiator;else if (c.id === "dateInitiated") content = r.date;else if (c.id === "actionButton") content = /*#__PURE__*/React.createElement("span", {
      style: {
        cursor: "pointer",
        padding: "2px 8px",
        fontSize: 13,
        background: "#e8f2ff",
        border: "1px solid #000"
      }
    }, "Take Action");else content = /*#__PURE__*/React.createElement("span", {
      style: {
        color: "#aaa"
      }
    }, "\u2014");
    return /*#__PURE__*/React.createElement("td", {
      key: c.id,
      style: td
    }, content);
  }))))))));
}
Object.assign(window, {
  ReportBuilderScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/request_portal/ReportBuilderScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/request_portal/data.js
try { (() => {
// Fake data for the LEAF Request Portal UI kit.
// Structure mirrors the real LeafFormQuery result blobs (recordID, title,
// service, categoryNames, status, date, priority, userID).

window.PORTAL_DATA = {
  site: {
    city: "VA Medical Center",
    title: "Office of Workflow Solutions",
    user: "Veteran, Jane Q."
  },
  // Request type categories shown on the "New Request" screen.
  categories: [{
    id: "leave",
    name: "General Leave Request",
    desc: "Annual, sick, or unpaid leave requests routed to your supervisor."
  }, {
    id: "equipment",
    name: "Equipment Request",
    desc: "Request a laptop, monitor, or other government-furnished equipment."
  }, {
    id: "telework",
    name: "Telework Agreement",
    desc: "Establish or update a recurring telework schedule."
  }, {
    id: "travel",
    name: "Travel Authorization",
    desc: "Pre-approval for official travel and per-diem estimates."
  }, {
    id: "access",
    name: "System Access Request",
    desc: "Request access to a VA application or shared drive."
  }],
  // Records shown in the homepage grid. tone drives the status color.
  records: [{
    id: 20482,
    title: "Annual Leave — June 24–28",
    service: "Cardiology",
    types: "General Leave Request",
    status: "Pending Supervisor Approval",
    tone: "wait",
    date: "June 6",
    mine: true,
    priority: 0
  }, {
    id: 20479,
    title: "Replacement laptop (cracked screen)",
    service: "Radiology",
    types: "Equipment Request",
    status: "Approved",
    tone: "done",
    date: "June 5",
    mine: false,
    priority: 0
  }, {
    id: 20475,
    title: "Emergency on-call coverage swap",
    service: "Emergency Dept",
    types: "General Leave Request",
    status: "Waiting for Chief of Staff",
    tone: "wait",
    date: "June 5",
    mine: false,
    priority: -10
  }, {
    id: 20471,
    title: "Telework — 3 days/week",
    service: "Health Informatics",
    types: "Telework Agreement",
    status: "Returned for edits",
    tone: "error",
    date: "June 3",
    mine: true,
    priority: 0
  }, {
    id: 20465,
    title: "Travel to regional training (Aug)",
    service: "Education",
    types: "Travel Authorization",
    status: "Waiting for Fiscal",
    tone: "wait",
    date: "June 2",
    mine: false,
    priority: 0
  }, {
    id: 20460,
    title: "CPRS access for new resident",
    service: "Medicine",
    types: "System Access Request",
    status: "Approved",
    tone: "done",
    date: "May 30",
    mine: false,
    priority: 0
  }, {
    id: 20454,
    title: "Standing desk — ergonomic accommodation",
    service: "Pharmacy",
    types: "Equipment Request",
    status: "Not Submitted",
    tone: "error",
    date: "May 29",
    mine: true,
    priority: 0
  }, {
    id: 20448,
    title: "Annual leave — July 4 week",
    service: "Nursing",
    types: "General Leave Request",
    status: "Approved",
    tone: "done",
    date: "May 27",
    mine: false,
    priority: 0
  }],
  // A single record's detail, for the record-view screen.
  detail: {
    id: 20482,
    title: "Annual Leave — June 24–28",
    service: "Cardiology",
    type: "General Leave Request",
    initiator: "Veteran, Jane Q.",
    submitted: "June 6, 2026",
    fields: [{
      label: "Requestor name",
      value: "Veteran, Jane Q."
    }, {
      label: "Service / Section",
      value: "Cardiology"
    }, {
      label: "Type of leave",
      value: "Annual leave"
    }, {
      label: "First day of leave",
      value: "06/24/2026"
    }, {
      label: "Last day of leave",
      value: "06/28/2026"
    }, {
      label: "Total hours requested",
      value: "40"
    }, {
      label: "Coverage arranged with",
      value: "Smith, Robert (Cardiology)"
    }, {
      label: "Justification / notes",
      value: "Pre-planned family travel. Coverage confirmed with Dr. Smith for all clinic days."
    }],
    workflow: [{
      step: "Submitted by requestor",
      who: "Veteran, Jane Q.",
      done: true,
      date: "Jun 6"
    }, {
      step: "Supervisor approval",
      who: "Diaz, Maria",
      current: true,
      done: false,
      date: null
    }, {
      step: "Service Chief approval",
      who: "Chief of Cardiology",
      done: false,
      date: null
    }, {
      step: "Timekeeper records leave",
      who: "Nguyen, An",
      done: false,
      date: null
    }]
  },
  // Inbox — records awaiting THIS user's action, organized by the role/step
  // they hold (report.php?a=LEAF_Inbox&organizeByRole).
  inbox: [{
    role: "Supervisor — Cardiology",
    items: [{
      id: 20482,
      title: "Annual Leave — June 24–28",
      initiator: "Veteran, Jane Q.",
      service: "Cardiology",
      days: 1,
      types: "General Leave Request"
    }, {
      id: 20468,
      title: "Conference travel — ACC 2026",
      initiator: "Patel, Anil",
      service: "Cardiology",
      days: 3,
      types: "Travel Authorization"
    }]
  }, {
    role: "Service Chief — Emergency Dept",
    items: [{
      id: 20475,
      title: "Emergency on-call coverage swap",
      initiator: "Brooks, Dana",
      service: "Emergency Dept",
      days: 2,
      types: "General Leave Request",
      priority: -10
    }, {
      id: 20461,
      title: "Replacement pulse oximeters (x4)",
      initiator: "Lowe, Sam",
      service: "Emergency Dept",
      days: 5,
      types: "Equipment Request"
    }, {
      id: 20457,
      title: "Telework — 2 days/week",
      initiator: "Reyes, Mia",
      service: "Emergency Dept",
      days: 6,
      types: "Telework Agreement"
    }]
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/request_portal/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.AdvancedSearch = __ds_scope.AdvancedSearch;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.SideNav = __ds_scope.SideNav;

})();
